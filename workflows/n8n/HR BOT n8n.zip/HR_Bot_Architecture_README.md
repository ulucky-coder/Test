# HR Bot v3.0 — Архитектура и Инструкция по Установке

## Обзор Архитектуры

HR Bot для BestHotel разбит на **8 изолированных workflow**, что обеспечивает:
- Независимое тестирование каждого компонента
- Быстрое исправление ошибок без побочных эффектов
- Масштабирование отдельных частей системы
- Улучшенную наблюдаемость (observability)

```
┌─────────────────────────────────────────────────────────────────┐
│                    HR BOT ARCHITECTURE v3.0                      │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  [Telegram Message]                                              │
│         │                                                        │
│         ▼                                                        │
│  ┌──────────────┐                                               │
│  │ 01_GATEWAY   │ ← Rate limit, spam filter                     │
│  └──────┬───────┘                                               │
│         │                                                        │
│         ▼                                                        │
│  ┌──────────────┐                                               │
│  │ 02_SESSION   │ ← Load/create session, history, vacancies     │
│  │   MANAGER    │                                               │
│  └──────┬───────┘                                               │
│         │                                                        │
│         ▼                                                        │
│  ┌──────────────┐                                               │
│  │ 03_ROUTER    │ ← AI classification → category                │
│  └──────┬───────┘                                               │
│         │                                                        │
│    ┌────┴────┬────────┬────────┬────────┐                       │
│    ▼         ▼        ▼        ▼        ▼                       │
│ ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐                   │
│ │ 04a  │ │ 04b  │ │ 04c  │ │ 04d  │ │ 04e  │                   │
│ │GREET │ │INTRV │ │ FAQ  │ │ESCAL │ │ LANG │                   │
│ └──┬───┘ └──┬───┘ └──┬───┘ └──┬───┘ └──┬───┘                   │
│    └────────┴────────┴────────┴────────┘                        │
│                      │                                           │
│                      ▼                                           │
│             ┌──────────────┐                                     │
│             │ 05_RESPONSE  │ ← Send message, save history       │
│             │   SENDER     │                                     │
│             └──────┬───────┘                                     │
│                    │ (if interview_complete)                     │
│                    ▼                                             │
│             ┌──────────────┐                                     │
│             │ 06_SCORING   │ ← Score + HR notification          │
│             │   ENGINE     │                                     │
│             └──────────────┘                                     │
│                                                                  │
│  ┌──────────────┐  ┌──────────────┐                             │
│  │ 07_ERROR     │  │ 08_HEALTH    │                             │
│  │  HANDLER     │  │   CHECK      │                             │
│  │ (Error Trig) │  │ (Schedule)   │                             │
│  └──────────────┘  └──────────────┘                             │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

## Файлы Workflow

| № | Файл | Назначение | Trigger |
|---|------|-----------|---------|
| 1 | `01_gateway.json` | Rate limiting, spam protection | Telegram Trigger |
| 2 | `02_session_manager.json` | Управление сессиями, загрузка контекста | Execute Workflow |
| 3 | `03_router.json` | AI-классификация сообщений | Execute Workflow |
| 4a | `04a_greeting_agent.json` | Приветствие новых пользователей | Execute Workflow |
| 4b | `04b_interview_agent.json` | Основное собеседование | Execute Workflow |
| 4c | `04c_faq_agent.json` | Ответы на вопросы о вакансиях | Execute Workflow |
| 4d | `04d_escalation_handler.json` | Эскалация к HR | Execute Workflow |
| 4e | `04e_language_handler.json` | Обработка выбора языка | Execute Workflow |
| 5 | `05_response_sender.json` | Отправка сообщений, сохранение истории | Execute Workflow |
| 6 | `06_scoring_engine.json` | Скоринг кандидатов, уведомление HR | Execute Workflow |
| 7 | `07_error_handler.json` | Централизованная обработка ошибок | Error Trigger |
| 8 | `08_health_check.json` | Мониторинг здоровья системы | Schedule (30 мин) |

## Инструкция по Установке

### Шаг 1: Подготовка базы данных

```bash
# Выполните миграции
psql -U your_user -d your_database -f migrations.sql
```

### Шаг 2: Импорт workflow в n8n

1. Откройте n8n
2. Перейдите в **Settings → Import from File**
3. Импортируйте файлы в следующем порядке:
   - `07_error_handler.json` (первым — для перехвата ошибок)
   - `08_health_check.json`
   - `06_scoring_engine.json`
   - `05_response_sender.json`
   - `04e_language_handler.json`
   - `04d_escalation_handler.json`
   - `04c_faq_agent.json`
   - `04b_interview_agent.json`
   - `04a_greeting_agent.json`
   - `03_router.json`
   - `02_session_manager.json`
   - `01_gateway.json` (последним)

### Шаг 3: Настройка связей между workflow

После импорта нужно связать workflow через ноды **Execute Workflow**:

1. В `01_gateway.json`:
   - Нода "Call Session Manager" → укажите ID `02_session_manager`

2. В `02_session_manager.json`:
   - Нода "Call Router" → укажите ID `03_router`

3. В `03_router.json`:
   - "Call Greeting Agent" → `04a_greeting_agent`
   - "Call Interview Agent" → `04b_interview_agent`
   - "Call FAQ Agent" → `04c_faq_agent`
   - "Call Escalation Handler" → `04d_escalation_handler`
   - "Call Language Handler" → `04e_language_handler`
   - "Call Interview (Fallback)" → `04b_interview_agent`

4. В каждом агенте (04a-04e):
   - Нода "Call Response Sender" → `05_response_sender`

5. В `05_response_sender.json`:
   - Нода "Call Scoring Engine" → `06_scoring_engine`

### Шаг 4: Настройка credentials

Убедитесь, что настроены:
- **Telegram API** (id: `cS1RormMvPe41m7M`, name: "Zest")
- **PostgreSQL** (id: `0AYoJYr8BGzKVyG6`, name: "Postgres account")
- **DeepSeek API** (id: `g1KQFdKf5EC4OIiO`, name: "DeepSeek account")

### Шаг 5: Настройка HR группы

В файлах используется chat_id: `-1003410305192`

Замените на ID вашей HR группы в следующих нодах:
- `04d_escalation_handler.json` → "Notify HR - Escalation"
- `06_scoring_engine.json` → все ноды "Notify HR - *"
- `07_error_handler.json` → "Notify HR - Critical Error"
- `08_health_check.json` → "Send Health Report"

### Шаг 6: Активация workflow

Активируйте в следующем порядке:
1. `07_error_handler` (Error Trigger)
2. `08_health_check` (Schedule Trigger)
3. `01_gateway` (Telegram Trigger)

## Исправленные Ошибки

### 1. Handle Language Selection (04e)
**Было:**
```javascript
const text = (context.user_message || '').toLowerCase();
const text = (context.user_message || '').toLowerCase(); // дубликат!
// ...
language = 'ru'; // не объявлена!
```

**Стало:**
```javascript
const text = (context.user_message || '').toLowerCase();
const callbackData = context.callback_data || '';

let language = 'ru';
let confirmation = '';
// ...
```

### 2. Send With Language Buttons
**Было:** Inline keyboard в поле `reply_to_message_id`

**Стало:** HTTP Request с правильным JSON body и `reply_markup`

### 3. Parse Router Response
**Было:** Опасный JSON.parse без проверки

**Стало:** Safe parsing с try-catch и fallback

### 4. Interview Agent
**Было:** Дублирование system prompt

**Стало:** Единый, оптимизированный промпт

## Мониторинг и Отладка

### Логи ошибок
```sql
SELECT * FROM error_logs 
ORDER BY timestamp DESC 
LIMIT 20;
```

### Health Check история
```sql
SELECT * FROM health_checks 
ORDER BY timestamp DESC 
LIMIT 50;
```

### Активные сессии
```sql
SELECT * FROM candidate_sessions 
WHERE status = 'in_progress'
ORDER BY started_at DESC;
```

### Последние одобренные
```sql
SELECT * FROM approved_candidates 
ORDER BY created_at DESC 
LIMIT 10;
```

## Контакты

При возникновении проблем проверьте:
1. Логи n8n (`docker logs n8n` или UI)
2. Таблицу `error_logs` в PostgreSQL
3. Health Check отчёты в HR группе
