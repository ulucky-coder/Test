-- ============================================================
-- HR BOT DATABASE MIGRATIONS v3.0
-- Run this script to create/update all required tables
-- ============================================================

-- 1. Error Logs Table (for Error Handler workflow)
CREATE TABLE IF NOT EXISTS error_logs (
    id SERIAL PRIMARY KEY,
    timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    severity VARCHAR(20) NOT NULL DEFAULT 'WARNING',
    workflow_name VARCHAR(255),
    workflow_id VARCHAR(100),
    execution_id VARCHAR(100),
    node_name VARCHAR(255),
    error_message TEXT,
    error_stack TEXT,
    raw_data TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_error_logs_timestamp ON error_logs(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_error_logs_severity ON error_logs(severity);
CREATE INDEX IF NOT EXISTS idx_error_logs_workflow ON error_logs(workflow_name);

-- 2. Health Checks Table (for Health Check workflow)
CREATE TABLE IF NOT EXISTS health_checks (
    id SERIAL PRIMARY KEY,
    timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    overall_status VARCHAR(50) NOT NULL,
    total_sessions INTEGER DEFAULT 0,
    active_sessions INTEGER DEFAULT 0,
    sessions_today INTEGER DEFAULT 0,
    errors_last_hour INTEGER DEFAULT 0,
    approved_today INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_health_checks_timestamp ON health_checks(timestamp DESC);

-- 3. Ensure candidate_sessions has all required columns
ALTER TABLE candidate_sessions 
ADD COLUMN IF NOT EXISTS language VARCHAR(10) DEFAULT 'ru';

ALTER TABLE candidate_sessions 
ADD COLUMN IF NOT EXISTS first_name VARCHAR(255);

-- Add unique constraint if not exists
DO $$ 
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'candidate_sessions_telegram_user_id_key'
    ) THEN
        ALTER TABLE candidate_sessions 
        ADD CONSTRAINT candidate_sessions_telegram_user_id_key 
        UNIQUE (telegram_user_id);
    END IF;
END $$;

-- 4. Ensure n8n_chat_histories has all required columns
ALTER TABLE n8n_chat_histories 
ADD COLUMN IF NOT EXISTS user_id BIGINT;

-- 5. Ensure approved_candidates has unique constraint
DO $$ 
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'approved_candidates_telegram_user_id_key'
    ) THEN
        ALTER TABLE approved_candidates 
        ADD CONSTRAINT approved_candidates_telegram_user_id_key 
        UNIQUE (telegram_user_id);
    END IF;
END $$;

-- 6. Create rejected_candidates table if not exists
CREATE TABLE IF NOT EXISTS rejected_candidates (
    id SERIAL PRIMARY KEY,
    telegram_user_id BIGINT NOT NULL,
    first_name VARCHAR(255),
    last_name VARCHAR(255),
    citizenship VARCHAR(100),
    age INTEGER,
    rejection_reason VARCHAR(100),
    score INTEGER,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_rejected_telegram_user ON rejected_candidates(telegram_user_id);
CREATE INDEX IF NOT EXISTS idx_rejected_created_at ON rejected_candidates(created_at DESC);

-- 7. Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_sessions_status ON candidate_sessions(status);
CREATE INDEX IF NOT EXISTS idx_sessions_telegram_user ON candidate_sessions(telegram_user_id);
CREATE INDEX IF NOT EXISTS idx_chat_history_session ON n8n_chat_histories(session_id);
CREATE INDEX IF NOT EXISTS idx_chat_history_created ON n8n_chat_histories(created_at DESC);

-- 8. Vacuum and analyze for optimization
VACUUM ANALYZE candidate_sessions;
VACUUM ANALYZE n8n_chat_histories;
VACUUM ANALYZE approved_candidates;

-- ============================================================
-- VERIFICATION QUERIES
-- ============================================================

-- Check all tables exist
SELECT table_name 
FROM information_schema.tables 
WHERE table_schema = 'public' 
AND table_name IN (
    'candidate_sessions', 
    'n8n_chat_histories', 
    'vacancies', 
    'approved_candidates',
    'rejected_candidates',
    'error_logs',
    'health_checks'
);

-- Check indexes
SELECT indexname, tablename 
FROM pg_indexes 
WHERE schemaname = 'public'
ORDER BY tablename, indexname;
